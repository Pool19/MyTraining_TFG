package src.rutina.app.Main;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import src.rutina.app.DaoImpl.*;
import src.rutina.app.Constants.*;
import src.rutina.app.Objects.*;

/*
 * Clase que representa un controlador REST de videos. Mapea las operaciones
 * sobre recursos REST relacionados con videos y hace uso del DAO para
 * hacerlas efectivas en la base de datos.

 */

@RestController
@ImportResource("classpath:spring/config/beanLocations.xml")
public class VideosController{

	// Obtenemos el DAO mediante inyección de dependencias
	@Autowired
	private VideosDaoImpl videosDao;

	// Obtiene un video de la base de datos
	@RequestMapping(value = UriConstants.VIDEOS, method = RequestMethod.GET)
	public @ResponseBody List<Videos> getVideo( 
			@PathVariable("ej_id") int ej_id) {

		return this.videosDao.getVideo(ej_id);
	}


	// Eliminar un video de la base de datos
	@RequestMapping(value = UriConstants.VIDEOS, method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteVideo(
			@PathVariable("user_id") String userId,
			@PathVariable("ej_id") int ej_id) {

			this.videosDao.deleteVideo(ej_id,userId);

	}

	/**
	 * POST /uploadFile -> receive and locally save a file.
	 * 
	 * @param uploadfile The uploaded file as Multipart file parameter in the 
	 * HTTP request. The RequestParam name must be the same of the attribute 
	 * "name" in the input tag with type file.
	 * 
	 * @return An http OK status in case of success, an http 4xx status in case 
	 * of errors.
	 */
	@RequestMapping(value = UriConstants.VIDEOS_ADD, method = RequestMethod.POST)
	@ResponseBody
	public void uploadFile(@PathVariable("ej_id") int ej_id,
			@RequestBody Videos video) {
		
		System.out.println("DATOS2: " + ej_id);
		
		this.videosDao.createVideo(video.getVideoNombre() , video.getVideoUrl() ,ej_id,video.getUserId());
		
	} // method uploadFile

	//Actualiza una video en la base de datos
	//Testear!!!
	@RequestMapping(value = UriConstants.VIDEOS, method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateVideo(@PathVariable("user_id") String userId,
			@PathVariable("ej_id") int ej_id,@RequestBody Videos video) {

		this.videosDao.updateVideo(video.getVideoNombre(), video.getVideoUrl(),ej_id,userId);
	}
}

