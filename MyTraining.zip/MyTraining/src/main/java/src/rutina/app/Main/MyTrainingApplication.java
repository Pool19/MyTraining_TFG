package src.rutina.app.Main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;



/*
 * Clase principal del servicio web 
 * 
 *
 */


@SpringBootApplication
public class MyTrainingApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(MyTrainingApplication.class);
    }
    
    @Bean
    public WebSecurityConfigurerAdapter webSecurityConfigurerAdapter() {
	return new SecurityConfiguration();
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(MyTrainingApplication.class, args);
    }

}