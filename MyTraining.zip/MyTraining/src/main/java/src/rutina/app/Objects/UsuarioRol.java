package src.rutina.app.Objects;

import java.sql.Date;

/*
 * Clase que representa un usuario en la aplicación.
 * 
 * 
 * Diseño: Pablo Carmona Rebollo
 * All rights reserved
 * version 3.0.0
 */

public class UsuarioRol {

	// El userId es el correo electrónico del Usuario

	private String userRole,userId;


	public UsuarioRol() {
	}

	public UsuarioRol(String userId, String userRole) {
		this.userRole = userRole;
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

}