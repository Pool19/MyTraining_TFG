package src.rutina.app.Constants;

/*
 * Clase que almacena los URIs accesibles del servicio REST.
 * 
 * 
 * Diseño: Pablo Carmona Rebollo
 * All rights reserved
 * version 3.0.0
 */

public class UriConstants {

    /* REGISTER Rutinas */
    public static final String USUARIOS_REGISTER = "/RutinaRegister//";
    
    /* OWNERS */
    public static final String USUARIO = "/Rutina_app/{user_id:.+}";
    public static final String USUARIO_PASS = "/SMS/{user_id:.+}/{phoneNumber:.+}";
    public static final String ALL_USUARIOS = "/Rutina_app//";
    public static final String ROL_US = "/Rutina_app/rol/{user_id:.+}";
    public static final String ALL_ROL_US = "/Rutina_app/rol/";
    
    /* RUTINAS*/
    public static final String RUTINA = "/Rutina_app/rutinas/{rut_id:.+}";
    public static final String RUTINAS = "/Rutina_app/rutinas/{user_id:.+}/{rut_id:.+}";
    public static final String RUTINAS1= "/Rutina_app/rutinas/publicas/{user_id:.+}";
    public static final String RUTINAS_DOWNLOAD = "/Rutina_app/downloads/{rut_id:.+}";
    public static final String ALL_RUTINAS = "/Rutina_app/rutinas/{user_id:.+}//";
    public static final String ALL_RUTINAS_USER = "/Rutina_app/rutinas_user/{user_id:.+}//";
    public static final String RUT_US = "/Rutina_app/rut/{user_id:.+}/";
    public static final String RUT_US_ADD = "/Rutina_app/rut/add/{user_id:.+}/";
    
    

    /* EJERCICIOS */
    public static final String EJERCICIOS = "/Rutina_app/ejercicios/{user_id:.+}/{ej_id:.+}";
    public static final String ALL_EJERCICIOS = "/Rutina_app/ejercicios/{user_id:.+}//";
    public static final String EJ_US = "/Rutina_app/ej/{user_id:.+}/";
    public static final String EJ_US_ADD = "/Rutina_app/ej/add/{user_id:.+}/";
    public static final String ALL_EJERCICIOS_USER = "/Rutina_app/ejercicios_user/{user_id:.+}//";

    /* VIDEOS */
    //public static final String ALL_VIDEOS = "/Rutina_app/videos/{owner_id:.+}//";
    public static final String VIDEOS = "/Rutina_app/videos/{user_id:.+}/{ej_id:.+}";
    public static final String VIDEOS_ADD = "/Rutina_app/videos/{ej_id:.+}";
    
    /*ASOCIACION DE EJERCICIOS A RUTINAS*/
    public static final String RUTINAS_EJERCICIOS = "/Rutina_app/rutinas/asociaciones/{rut_id:.+}/{ej_id:.+}";
    public static final String ALL_RUTINAS_EJERCICIOS = "/Rutina_app/rutinas/asociaciones/{rut_id:.+}//";
    public static final String ALL_RUTINAS_NO_EJERCICIOS= "/Rutina_app/rutinas/noasociaciones/{rut_id:.+}//";
}
