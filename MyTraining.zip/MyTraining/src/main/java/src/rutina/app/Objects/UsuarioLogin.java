package src.rutina.app.Objects;

import java.sql.Date;

/*
 * Clase que representa un usuario en la aplicación.
 * 
 * 
 * Diseño: Pablo Carmona Rebollo
 * All rights reserved
 * version 3.0.0
 */

public class UsuarioLogin {

	// El userId es el correo electrónico del Usuario

	private String userPassw;


	public UsuarioLogin() {
	}

	public UsuarioLogin(String userPassw) {
		this.userPassw = userPassw;
	}

	public String getUserPassw() {
		return userPassw;
	}

	public void setUserPassw(String userPassw) {
		this.userPassw = userPassw;
	}

}