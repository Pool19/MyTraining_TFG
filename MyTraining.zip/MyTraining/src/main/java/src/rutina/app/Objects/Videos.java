package src.rutina.app.Objects;

/*
 * Clase que representa un Vvideo en la aplicación.
 * 
 * 
 */


public class Videos {

	private int ej_id;
	private String userId;
	private String videoNombre;
	private String videoUrl;

	public Videos(String videoNombre, String videoUrl,int ej_id,String userId) {
		this.videoNombre=videoNombre;
		this.videoUrl=videoUrl;
		this.userId=userId;
		this.ej_id=ej_id;
		
		System.out.println("DATOS3: " + ej_id);

	}

	public Videos(){
	}


	public int getEj_Id() {
		return ej_id;
	}

	public void setEj_Id(int ej_id) {
		this.ej_id = ej_id;
	}

	public String getVideoNombre() {
		return videoNombre;
	}

	public void setVideoNombre(String videoNombre) {
		this.videoNombre = videoNombre;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


}
