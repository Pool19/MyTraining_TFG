		  	function redireccion(){
		  		
		  		window.location.href = "EjercicioAdd.html";
		  	}