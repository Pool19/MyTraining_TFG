
/*
 * Controlador de la página EjercicioAdd.html
 * 
 *
 */


/* Funciones a ejecutar en la carga de la página */
$(document).ready(function() {
	//Para rellenar el select de usuarios
	getUserData();
	
	// Inicializamos el plugin de validación
	$('#ejercicio_form').validate({
		// Establecemos las reglas de validación para
		// cada uno de los campos del formulario
		rules : {
			ejercicio_user : {
				required : true,
			},
			ejercicio_nombre : {
				required : true,
				minlength : 2
			},
			/*ejercicio_titulo : {
				required : true,
				minlength : 2,
				maxlength : 200
			},	*/		
			ejercicio_nomUs: {
				required : true,
				minlength : 2
			},
			ejercicio_descripcion: {
				required : true,
				minlength : 2,
			},
			ejercicio_estadoforma: {
				required : true
			},
			ejercicio_repeticiones: {
				required : true
			},
		},
		// Establecemos la función que se ejecutará en caso
		// de envío del formulario.
		submitHandler : function(form) {
			sendEjercicioData();
		}
	});

});


/* Evento que lanza el envío del formulario */
function submitForm() {
	$("#ejercicio_form").submit();
}

/* Función de extracción y envío de los datos del formulario */
function sendEjercicioData() {

	// Obtenemos los datos del ejercicio del formulario
	var ejercicio_user = $('[name="ejercicio_user"]').val();
	var ejercicio_Pub_Priv = $('[name="ejercicio_Pub_Priv"]').val();
	
	console.log(!($.isEmptyObject(ejercicio_user)));
	console.log(ejercicio_Pub_Priv);
	
	if($.isEmptyObject(ejercicio_user)){
			alert("El campo de usuario está vacío.");
	}
	else{
		// Obtenemos la cookie
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		
		var ejercicio_nombre = $('[name="ejercicio_nombre"]').val();
		//var ejercicio_titulo = $('[name="ejercicio_titulo"]').val();
		var ejercicio_nomUs = $('[name="ejercicio_nomUs"]').val();
		var ejercicio_descripcion = $('[name="ejercicio_descripcion"]').val();
		var ejercicio_estadoforma = $('[name="ejercicio_estadoforma"]').val();
		var ejercicio_repeticiones = $('[name="ejercicio_repeticiones"]').val();
		var ejercicio_Pub_Priv = $('[name="ejercicio_Pub_Priv"]').val();
		
		console.log("--------");
		console.log(ejercicio_nombre);
		console.log(ejercicio_nomUs);
		console.log(ejercicio_descripcion);
		console.log(ejercicio_estadoforma);
		console.log(ejercicio_repeticiones);
		console.log(ejercicio_Pub_Priv);
			
		var j = 1;
		
		// JSON formado con los datos del formulario extraídos
		var rutina_json = {
			userId : cookie.userid,
			ejercicioNombre: ejercicio_nombre,
			//ejercicioTitulo : ejercicio_titulo,
			ejercicioSubtitulo: ejercicio_nomUs,
			ejercicioDescripcion : ejercicio_descripcion,
			ejercicioEstado_Forma : ejercicio_estadoforma,
			ejercicioRepeticiones: ejercicio_repeticiones,
			ejercicioPub_Priv: ejercicio_Pub_Priv
		};
				
		// Añadimos el ejercicio a la base de datos
		$.ajax({
			url : "/Rutina_app/ejercicios/" + cookie.userid + "/" + "?ejercicio_Pub_Priv=" + ejercicio_Pub_Priv,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "POST",
			data : JSON.stringify(rutina_json),
			contentType : "application/json",
			async:false,
		// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			alert("Ejercicio añadido con éxito al Especialista");
		// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("Se ha producido un error.");
		});
				
		// Obtenemos ID de rutinas
		$.ajax({
			url : "/Rutina_app/ej/" + cookie.userid + "/" + "?ejercicio_nombre="+ ejercicio_nombre +"&ejercicio_subtitulo=" + ejercicio_nomUs +"&ejercicio_descripcion=" + ejercicio_descripcion +"&ejercicio_estadoForma=" + ejercicio_estadoforma +"&ejercicio_repeticiones=" + ejercicio_repeticiones,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "GET",
			dataType : "json",
			// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			
			console.log("DATA:  "+data);
			crearEjercicioAsociado(data);
			
		// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("Se ha producido un error.");
		});
		
	}
}


function crearEjercicioAsociado(jsonRutIdArray){
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var j = 0;
	
	var objeto = jsonRutIdArray[0];
	console.log(objeto);
	
	var ejercicio_user = $('[name="ejercicio_user"]').val();
	var ejercicio_nombre = $('[name="ejercicio_nombre"]').val();
	//var ejercicio_titulo = $('[name="ejercicio_titulo"]').val();
	var ejercicio_nomUs = $('[name="ejercicio_nomUs"]').val();
	var ejercicio_descripcion = $('[name="ejercicio_descripcion"]').val();
	var ejercicio_estadoforma = $('[name="ejercicio_estadoforma"]').val();
	var ejercicio_repeticiones = $('[name="ejercicio_repeticiones"]').val();
	var ejercicio_Pub_Priv = $('[name="ejercicio_Pub_Priv"]').val();
	
	
	$(ejercicio_user).each(function(i){
		console.log("usuario: " + ejercicio_user[i]);
		
	
		var rutina_json = {
				ej_id : objeto.ej_id,
				userId : ejercicio_user[i],
				ejercicioNombre: ejercicio_nombre,
				//ejercicioTitulo : ejercicio_titulo,
				ejercicioSubtitulo: ejercicio_nomUs,
				ejercicioDescripcion : ejercicio_descripcion,
				ejercicioEstado_Forma : ejercicio_estadoforma,
				ejercicioRepeticiones: ejercicio_repeticiones,
				ejercicioPub_Priv: ejercicio_Pub_Priv
			};
		
		$.ajax({
			url : "/Rutina_app/ej/add/" + ejercicio_user[i] + "/" ,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "POST",
			data : JSON.stringify(rutina_json),
			contentType : "application/json",
			async:false,
		// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			j += 1;

		// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("Se ha producido un error.");
		});
	});

	if(ejercicio_user.length == j){
		alert("Ejercicio añadida con éxito");
		window.location.href = "EjerciciosList.html?ejercicio_Pub_Priv=false";
	}
}


/* Función que obtiene los datos del usuario de la base de datos */
function getUserData() {
	
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));

	// Obtenemos la información del usuario de la base de datos
	$.ajax({
		url : "/Rutina_app/rol/",
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		dataType : "json",
		cache : false,
		async:false,
	}).done(function (data, textStatus, jqXHR) {
		rellenaEmails(data);
	// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error.");
	});
}


/* Función que rellena con los emails (id) de los usuarios la tabla de selección de estos */
function rellenaEmails(jsonUserArray) {
	
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var select = $("#select");
	// Iteramos para cada una de los usuarios
	for (var i = 0; i < jsonUserArray.length; i++) {
		var obj = jsonUserArray[i];
		if(cookie.userid != obj.userId && obj.userRole == "ROLE_USER")
			select.append('<option value="' + obj.userId + '">'+ obj.userId +'</option>');		
	}
}

