		  	function redireccion(){
		  		
		  		window.location.href = "RutinaAdd.html";
		  	}