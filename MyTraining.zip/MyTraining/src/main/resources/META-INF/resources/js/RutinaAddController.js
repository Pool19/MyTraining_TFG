
/*
 * Controlador de la página RutinaAdd.html
 * 
 *
 */


/* Funciones a ejecutar en la carga de la página */
$(document).ready(function() {
	//Para rellenar el select de usuarios
	getUserData();
	// Inicializamos el plugin de validación
	$('#rutina_form').validate({
		// Establecemos las reglas de validación para
		// cada uno de los campos del formulario
		rules : {
			rutina_user : {
				required : true,
			},
			rutina_name : {
				required : true,
				minlength : 2
			},
			rutina_description : {
				required : true,
				minlength : 20,
			},			
			rutina_info: {
				required : true
			},
		},
		
		// Establecemos la función que se ejecutará en caso
		// de envío del formulario.
		submitHandler : function(form) {

			sendRutinaData();
		}
	});

});


/* Evento que lanza el envío del formulario */
function submitForm() {

	$("#rutina_form").submit();
}


/* Función de extracción y envío de los datos del formulario */
function sendRutinaData() {

	// Obtenemos los datos de la rutina del formulario
	var rutina_user = $('[name="rutina_user"]').val();
	var rutina_Pub_Priv = $('[name="rutina_Pub_Priv"]').val();
	
	console.log(!($.isEmptyObject(rutina_user)));
	console.log(rutina_Pub_Priv);
	
	if($.isEmptyObject(rutina_user)){
			alert("El campo de usuario está vacío.");
	}
	else{
		
		var rutina_name = $('[name="rutina_name"]').val();
		var rutina_description = $('[name="rutina_description"]').val();
		var rutina_info = $('[name="rutina_info"]').val();
		var rutina_Pub_Priv = $('[name="rutina_Pub_Priv"]').val();
		
		// Obtenemos la cookie
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		
		var j = 1;
			
			console.log (rutina_user);
			console.log (rutina_name);
			console.log (rutina_description);
			console.log (rutina_info);
			console.log (rutina_Pub_Priv);
			
			// JSON formado con los datos del formulario extraídos
			
			var rutina_json = {
				userId : cookie.userid,
				rutinaNombre : rutina_name,
				rutinaDescripcion : rutina_description,
				rutinaInfo_Rutina : rutina_info,
				rutinaPub_Priv : rutina_Pub_Priv
			};
			
			// Añadimos la rutina a la base de datos
			$.ajax({
				url : "/Rutina_app/rutinas/" + cookie.userid + "/",
				headers: {'X-CSRF-TOKEN': cookie.csrf},
				type : "POST",
				data : JSON.stringify(rutina_json),
				contentType : "application/json",
				async:false, // Hey browser! first complete this request, 
                			// then go for other codes
				// En caso de éxito: informamos y redirigimos
			}).done(function (data, textStatus, jqXHR) {
					alert("Rutina añadida con éxito al Especialista");			
		
			// Avisamos al usuario de que ha surgido un error
			}).fail(function (jqXHR, textStatus, errorThrown) {
				alert("Se ha producido un error.");
			});
							
				// Obtenemos ID de rutinas
				$.ajax({
					url : "/Rutina_app/rut/" + cookie.userid + "/" + "?rutina_nombre="+ rutina_name +"&rutina_description=" + rutina_description + "&rutina_info=" + rutina_info,
					headers: {'X-CSRF-TOKEN': cookie.csrf},
					type : "GET",
					dataType : "json",
					// En caso de éxito: informamos y redirigimos
				}).done(function (data, textStatus, jqXHR) {
					
					console.log("DATA:  "+data);
					crearRutinaAsociada(data);
					
			
				// Avisamos al usuario de que ha surgido un error
				}).fail(function (jqXHR, textStatus, errorThrown) {
					alert("Se ha producido un error.");
				});
	}
}

function crearRutinaAsociada(jsonRutIdArray){
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var j = 0;
	
	var objeto = jsonRutIdArray[0];
	console.log(objeto);
	
	var rutina_user = $('[name="rutina_user"]').val();
	var rutina_Pub_Priv = $('[name="rutina_Pub_Priv"]').val();
	var rutina_name = $('[name="rutina_name"]').val();
	var rutina_description = $('[name="rutina_description"]').val();
	var rutina_info = $('[name="rutina_info"]').val();
	var rutina_Pub_Priv = $('[name="rutina_Pub_Priv"]').val();
	
	$(rutina_user).each(function(i){
		console.log("usuario: " + rutina_user[i]);
		
	
		var rutina_json = {
				rut_id : objeto.rut_id,
				userId : rutina_user[i],
				rutinaNombre : rutina_name,
				rutinaDescripcion : rutina_description,
				rutinaInfo_Rutina : rutina_info,
				rutinaPub_Priv : rutina_Pub_Priv
			};
		
		$.ajax({
			url : "/Rutina_app/rut/add/" + rutina_user[i] + "/" ,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "POST",
			data : JSON.stringify(rutina_json),
			contentType : "application/json",
			async:false,
		// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			j += 1;

		// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("Se ha producido un error.");
		});
	});

	if(rutina_user.length == j){
		alert("Rutina añadida con éxito");
		window.location.href = "RutinasList.html?rutina_Pub_Priv=false";
	}
}







/* Función que obtiene los datos del usuario de la base de datos */
function getUserData() {
	console.log("GETUSERDATA");
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));

	// Obtenemos la información del usuario de la base de datos
	$.ajax({
		url : "/Rutina_app/rol/",
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		dataType : "json",
		cache : false,
		async:false,
	}).done(function (data, textStatus, jqXHR) {
		console.log(data);
		rellenaEmails(data);
	// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error.");
	});
}


/* Función que rellena con los emails (id) de los usuarios la tabla de selección de estos */
function rellenaEmails(jsonUserArray) {
	
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var select = $("#select");
	// Iteramos para cada una de los usuarios 
	for (var i = 0; i < jsonUserArray.length; i++) {
		var obj = jsonUserArray[i];
		console.log(obj.userId);
		if(cookie.userid != obj.userId && obj.userRole == "ROLE_USER")
			select.append('<option value="' + obj.userId + '">'+ obj.userId +'</option>');
	
	}
}
