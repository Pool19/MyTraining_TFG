
/*
 * Controlador de la página SeeVideo.html
 * 
 * 
 *
 */


/* Funciones a ejecutar en la carga de la página */
$(document).ready(function() {
	repvideo();
});


/* Funcion que permite la visualizacion de un video de un ejercicio */
function repvideo() {
	// Obtenemos el contenedor donde imprimiremos los ejercicios
	var container = $("#videCont")[0];

	var userid = getUrlParameter('user_id');
	var ej_id = getUrlParameter('ej_id');
	var json = getVideoData(ej_id);
	console.log("JSON video URL: " + json.videoUrl);
	var url = json[0].videoUrl;
	var url1 = url.split("v=");
	var url2 = url1[1].split("&");
	console.log("URL: " + url + "URL2: " + url2);


	console.log(ej_id);
	var summedSeeVideo ="<h3 class='text-center'>" + json[0].videoNombre + "</h3>" 
		+ "<iframe class='youtube' "
		+"src='https://www.youtube.com/embed/" 
		+ url2[0] + "?rel=0'"
		+"frameborder='0' allow='autoplay; encrypted-media' allowfullscreen></iframe>"
				
		container.innerHTML += summedSeeVideo;

}

function getVideoData(ej_id){
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var json;

	$.ajax({
		url : "/Rutina_app/videos/" + cookie.userid + "/" + ej_id,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		dataType : "json",
		async:false,
		// En caso de éxito: imprimimos un resumen de los ejercicios
	}).done(function (data, textStatus, jqXHR) {
		console.log(data);
		json=data;
		// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error");
	});	

	return json;
}



