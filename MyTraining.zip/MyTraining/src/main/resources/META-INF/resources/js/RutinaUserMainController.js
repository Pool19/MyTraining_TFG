
/*
 * Controlador de la página RutinaMain.html
 * 
 * 
 *
 */


/* Funciones a ejecutar en la carga de la página */
$(document).ready(function() {

	$('[data-toggle="tooltip"]').tooltip();

		getMisRutinasData("");

});

/* Función que obtiene los datos de todas las rutinas de un propietario */
function getMisRutinasData( busqueda) {

	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));

	$.ajax({
		url : "/Rutina_app/rutinas_user/" + cookie.userid + "/" + "?rutina_busqueda="+busqueda,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		dataType : "json",
		// En caso de éxito: imprimimos un resumen de las rutinas
	}).done(function (data, textStatus, jqXHR) {
		console.log("DATA: "+data);
		printMisRutinasData(data);
		// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error");
	});
}


/* Función que imprime un resumen de todas rutinas de un propietario 
   en una tabla */
function printMisRutinasData(jsonRutinasArray) {
	// Obtenemos el contenedor donde imprimiremos los locales
	var container = $(".print-rutinas")[0];

	if (jsonRutinasArray.length == 0)
	{
		$(".print-rutinas").hide();
		$("#text-info").show();
		$(".leyenda").hide();
		cabeceraprivada();
	}
	else
	{
		$(".print-rutinas").show();
		$("#text-info").hide();
		$(".leyenda").show();
		cabeceraprivada();
		// Iteramos para cada una de las rutinas e imprimimos sus campos
		for (var i = 0; i < jsonRutinasArray.length; i++) {
			var obj = jsonRutinasArray[i];

			var summedRutinaInfo = "<tr>" + "<td>"
			+ obj.rutinaNombre
			+ "</td>"
			+ "<td>"
			+ obj.rutinaDescripcion
			+ "</td>"
			+ "<td>"
			+ obj.rutinaInfo_Rutina
			+ "</td>"
			+ "<td>"
			+ "<a href='EjerciciosDeRutinaMain.html?rut_Id="//En este html, deben mostrarse los ejercicios de una rutina
			+ obj.rut_id
			+"&rutPub=nopub"
			+ "' data-toggle='tooltip' title='Ejercicios Asociados'><i class='material-icons'>assignment</i></a>"
			+ "<a onclick='downloadRutinaData("
			+ obj.rut_id
			+ ")' data-toggle='tooltip' title='Descargar Rutina'><i class='material-icons'>file_download</i></a>"
			+ "</td>" + "</tr>"
			

			container.innerHTML += summedRutinaInfo;

		}
	}
}


//Añade informacion de cabecera para las rutinas privadas
function cabeceraprivada()
{
	var cab= "<h2>" +
	"Mis Rutinas<small>Estas son las Rutinas qeu los Especialistas le han asignado para su entrnamiento." +
	"</small></h2>";

	var container = $(".cabecera");


	container.empty();
	container.prepend(cab);	
}


//Obtiene el campo para realizar la busqueda de una rutina.
function busqueda()
{

	// Obtenemos los datos de la rutina del formulario
	var rutina_busqueda = $('[name="rutina_busqueda"]').val();
	console.log(rutina_busqueda);


	$('.print-rutinas tbody tr').slice(0).remove();

	getMisRutinasData(rutina_busqueda);
	
	$('[name="rutina_busqueda"]').val("");


}

//Funcion para preparar la descarga de una rutina de un propiertario
function downloadRutinaData(RutinaId){
	var control=true;
	 control= getMisEjerciciosDeRutinaData(RutinaId);
	console.log(control);
	
	if(control==false){
		if(confirm("Esta rutina va a proceder a descargarse. Asegúrese de que en su equipo existe " +
				"el directorio 'C:\\Users\\Pablo\\Documents\\fileupload2\\zip' antes de confirmar si usa Windows.")){
			// Obtenemos la cookie
			var cookie = JSON.parse($.cookie('RutinaUsuario'));
			$.ajax({
				url : "/Rutina_app/downloads/"+ RutinaId + "?rutPub=nopub",
				headers: {'X-CSRF-TOKEN': cookie.csrf},
				type : "POST",
				async: false,
				// En caso de éxito: informamos y redirigimos
			}).done(function (data, textStatus, jqXHR) {
				//window.location.href = "/rutina_app/zip/rutina_"+RutinaId+".zip";
				alert("Rutina Descargada.");
				// Avisamos al usuario de que ha surgido un error
			}).fail(function (jqXHR, textStatus, errorThrown) {
				alert("No es posible descargar la rutina.");
			});					
		}
	}
	else{
		// Obtenemos la cookie
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		$.ajax({
			url : "/Rutina_app/downloads/" + cookie.userid + "/"
			+ RutinaId + "?rutPub=nopub",
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "POST",
			async: false,
			// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			//window.location.href = "/rutina_app/zip/rutina_"+RutinaId+".zip";
			alert("Rutina Descargada.");
			// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("No es posible descargar la rutina.");
		});		
	}
			
}
/*
//Funcion para preparar la descarga de una rutina publica
function downloadRutinaData1(RutinaId){
	
	
	var control=true;
	 control= getEjerciciosDeRutinaPublicosData(RutinaId);
	console.log(control);
	
	if(control==false){
		if(confirm("Esta rutina tiene algunos ejercicios sin videos asociados. si continua con la descarga, " +
				"no se añadiran aquellos ejercicios que carecen de videos")){
			// Obtenemos la cookie
			var cookie = JSON.parse($.cookie('RutinaUsuario'));
			$.ajax({
				url : "/Rutina_app/downloads/" + cookie.userid + "/"
				+ RutinaId + "?rutPub=pub",
				headers: {'X-CSRF-TOKEN': cookie.csrf},
				type : "POST",
				async: false,
				// En caso de éxito: informamos y redirigimos
			}).done(function (data, textStatus, jqXHR) {
				window.location.href = "/rutina_app/zip/rutina_"+RutinaId+".zip";
				alert("Rutina Descargada.");
				// Avisamos al usuario de que ha surgido un error
			}).fail(function (jqXHR, textStatus, errorThrown) {
				alert("No es posible descargar la rutina.");
			});
		}
	}
	else
		{
		// Obtenemos la cookie
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		$.ajax({
			url : "/Rutina_app/downloads/" + cookie.userid + "/"
			+ RutinaId + "?rutPub=pub",
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "POST",
			async: false,
			// En caso de éxito: informamos y redirigimos
		}).done(function (data, textStatus, jqXHR) {
			window.location.href = "/rutina_app/zip/rutina_"+RutinaId+".zip";
			alert("Rutina Descargada.");
			// Avisamos al usuario de que ha surgido un error
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("No es posible descargar la rutina.");
		});				
		}
	

}
*/

/* Función que obtiene los datos de todas las todos los ejercicios asociados a una rutina
 * y comprueba si algun ejercicio no tiene video asociado*/
function getMisEjerciciosDeRutinaData(RutinaId) {

	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var control=true;
	var resp;
	$.ajax({
		url : "/Rutina_app/rutinas/asociaciones/" + RutinaId + "/"+"?rutPub=nopub",
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		async: false,
		dataType : "json",
		// En caso de éxito: imprimimos un resumen de las asociaciones
	}).done(function (data, textStatus, jqXHR) {
		resp=data;
		if(resp.length==0)
			{
				 control=false;
			}
		else{
			for(i=0;i<resp.length;i++){
				
				var obj = resp[i];

				var id=obj.ej_id;

				var videojson=getVideoData(id);
				if(videojson.length==0){
				control=false;
				}

			}
			}
		// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error");
	});
	return control;
}




//IMORTANTE: Ajax es asincrono, lo cual debe ponerse sincrono para coger el valor
//de la respuesta correctamente y poder gestionarlo con JQuery
function getVideoData(ej_id){
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var json;

	$.ajax({
		url : "/Rutina_app/videos/" + cookie.userid + "/" + ej_id,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		dataType : "json",
		async:false,
		// En caso de éxito: imprimimos un resumen de los ejercicios
	}).done(function (data, textStatus, jqXHR) {
		//console.log(data);
		json=data;
		// Avisamos al usuario de que ha surgido un error
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error");
	});	

	return json;
}

$("#buscar").keypress(function(e) {
    if(e.which == 13) {
       // Acciones a realizar, por ej: enviar formulario.
       busqueda();
    }
 });