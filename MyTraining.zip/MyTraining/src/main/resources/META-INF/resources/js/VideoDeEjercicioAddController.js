/*
 * Controlador de la página VideosAdd.html
 * 
 * 
 *
 */


$(document).ready(function() {
	$('#upload-file-form').validate({
		// Establecemos las reglas de validación para
		// cada uno de los campos del formulario
		rules : {
			video_name : {
				required : true,
			},
			video_url : {
				required : true,
			},
		},
		// Establecemos la función que se ejecutará en caso
		// de envío del formulario.
		submitHandler : function(form) {
			uploadFile();
		}
	});
});

/* Evento que lanza el envío del formulario */
function submitForm() {
	$("#upload-file-form").submit();	
}

/**
 * Upload the file sending it via Ajax at the Spring Boot server.
 */
function uploadFile() {

	var ej_id = getUrlParameter('ej_id');
	var video_name = $('[name="video_name"]').val();
	var video_url = $('[name="video_url"]').val();
	
	// Obtenemos la cookie
	var cookie = JSON.parse($.cookie('RutinaUsuario'));  
	
	var video_json = {
			userId : cookie.userid,
			videoNombre : video_name,
			videoUrl : video_url,
		};
	
	
	console.log(ej_id);
	$.ajax({
		url: "/Rutina_app/videos/" + ej_id,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type: "POST",
		data:  JSON.stringify(video_json),
		contentType : "application/json",
		/*data:new FormData($("#upload-file-form")[0]),
		enctype: 'multipart/form-data',
		processData: false,
		contentType: false,
		cache: false,*/
	}).done(function (data, textStatus, jqXHR) {
			alert("Video Asociado");
			window.location.href = "EjerciciosList.html?ejercicio_Pub_Priv=false";
	}).fail(function (jqXHR, textStatus, errorThrown) {
			// Handle upload error
			alert("Video No Asociado");
			//window.location.href = "EjercicioMain.html";
	});
} // function uploadFile




    
    
    