$(document).ready(function(){$("#borroso").mouseover(function(){$(this).removeClass("elementborroso")})});

