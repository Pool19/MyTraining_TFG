
var phoneNumber= '';

$(document).ready(function() {
	// Inicializamos el plugin de validación
	$('#login_form').validate({
		// Establecemos las reglas de validación para
		// cada uno de los campos del formulario
		rules : {
			user_email : {
				required : true,
				email : true
			},
			phone : {
				required : true,
				minlength : 9,
				maxlength : 9
			}			
		},
		// Establecemos la función que se ejecutará en caso
		// de envío del formulario.
		submitHandler : function(form) {
			smsLogin();
		}
	});

});

var bandera = 0;
/* Evento que lanza el envío del formulario */
function submitForm() {
	$("#login_form").submit();
}

/*function SMSLogin(){
    var user_Id = $('[name="user_email"]').val();
    var pass = "";
    
    
    //Obtener password
	  	// Obtenemos la cookie
	  	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	  	console.log(cookie.userid);

	  	// Obtenemos la información del usuario de la base de datos
	  	$.ajax({
	  		url : "/Rutina_app/sms/" + user_Id,
	  		headers: {'X-CSRF-TOKEN': cookie.csrf},
	  		type : "GET",
	  		dataType : "json",
	  		async:false,
	  	}).done(function (data, textStatus, jqXHR) {
	  		
	  		pass = data[0].userPassw;
	  		
	  	// Avisamos al usuario de que ha surgido un error
	  	}).fail(function (jqXHR, textStatus, errorThrown) {
	  		alert("Se ha producido un error.");
	  	});
    
    //Login
	  var data = 'username=' + user_Id + '&password=' + pass; 
	  var cookie = JSON.parse($.cookie('RutinaUsuario'));
	  alert(user_Id);
	
		$.ajax({
			data: data,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			//timeout: 1000,
			type: "POST",
			url: "/login"

		}).done(function(data, textStatus, jqXHR) {
			// No se informa de nada: 
			// La autenticación del usuario es autodescriptiva		
			// Almacenamos en la cookie RutinaUser la información del usuario
			var cookie = JSON.stringify({method: '', url: '/', csrf: jqXHR.getResponseHeader('X-CSRF-TOKEN'), userid: user_Id});
			$.cookie('RutinaUsuario', cookie);

			// Obtenemos la cookie nueva
			var cookie = JSON.parse($.cookie('RutinaUsuario'));
			// Redireccionamos
			alert("Login correcto");
			window.location.href = "WelcomeRutinaApp.html";
			
		}).fail(function(jqXHR, textStatus, errorThrown) {
			//alert("FALLO1");
			// Informamos de que ha fallado la autenticación
			alert("La contraseña o el correo son erróneos");
			// Redirigimos si recarga la página para recargar la cookie
			//window.location.href = "login.html";
		});
}*/

// initialize Account Kit with CSRF protection	 
AccountKit_OnInteractive = function(){
    AccountKit.init(
      {
        appId:"1826347254092121", 
        state:"qwertrertrtwquipteqgpoqnpovnto", 
        version:"v1.1",
        fbAppEventsEnabled:true,
        //redirect:"/"
      }
    );
  };
 // login callback
 function loginCallback(response) {
	  if (response.status === "PARTIALLY_AUTHENTICATED") {
	      var code = response.code;
	      var csrf = response.state;
	      // Send code to server to exchange for access token

	      var user_Id = $('[name="user_email"]').val();
	      var phoneNumber = $('[name="phone"]').val();
	      var pass = "";
	      
	      
	      //Obtener password

		  	// Obtenemos la cookie
		  	var cookie = JSON.parse($.cookie('RutinaUsuario'));
		  	console.log(cookie.userid);
	
		  	// Obtenemos la información del usuario de la base de datos
		  	$.ajax({
		  		url : "/SMS/" + user_Id + "/" + phoneNumber,
		  		headers: {'X-CSRF-TOKEN': cookie.csrf},
		  		type : "GET",
		  		dataType : "json",
		  		async:false,
		  	}).done(function (data, textStatus, jqXHR) {
		  		
		  		pass = data[0].userPassw;
		  		
		  	// Avisamos al usuario de que ha surgido un error
		  	}).fail(function (jqXHR, textStatus, errorThrown) {
		  		alert("Se ha producido un error.");
		  	});
	      
	      //Login
		  var data = 'username=' + user_Id + '&password=' + pass; 
		  var cookie = JSON.parse($.cookie('RutinaUsuario'));
		  alert(user_Id);
	  	
			$.ajax({
				data: data,
				headers: {'X-CSRF-TOKEN': cookie.csrf},
				//timeout: 1000,
				type: "POST",
				url: "/login"

			}).done(function(data, textStatus, jqXHR) {
				// No se informa de nada: 
				// La autenticación del usuario es autodescriptiva		
				// Almacenamos en la cookie RutinaUser la información del usuario
				var cookie = JSON.stringify({method: '', url: '/', csrf: jqXHR.getResponseHeader('X-CSRF-TOKEN'), userid: user_Id});
				$.cookie('RutinaUsuario', cookie);

				// Obtenemos la cookie nueva
				var cookie = JSON.parse($.cookie('RutinaUsuario'));
				// Redireccionamos
				//alert("Login correcto");
				getUserRole();
				
			}).fail(function(jqXHR, textStatus, errorThrown) {
				//alert("FALLO1");
				// Informamos de que ha fallado la autenticación
				alert("La contraseña o el correo son erróneos");
				// Redirigimos si recarga la página para recargar la cookie
				//window.location.href = "login.html";
			});
	  }
	  else if (response.status === "NOT_AUTHENTICATED") {
		  // handle authentication failure
	      alert("Fallo de autenticación");
	  }
	  else if (response.status === "BAD_PARAMS") {
	      // handle bad parameters
	  }
	}

  // phone form submission handler
  function smsLogin() {
    var countryCode = '+34';
    var phoneNumber = $('[name="phone"]').val();
    
	    AccountKit.login(
	      'PHONE', 
	      {countryCode: countryCode, phoneNumber: phoneNumber}, // will use default values if not specified
	      loginCallback
	    );
  }
  
  function getUserRole(){
		
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		//console.log("COOKIE: " + cookie.userid);
		
		$.ajax({
			url : "/Rutina_app/rol/" + cookie.userid,
			headers: {'X-CSRF-TOKEN': cookie.csrf},
			type : "GET",
			contentType : "application/json",
			async:false,
		}).done(function(data, textStatus, jqXHR) {
			//Redireccionamos
			//alert("Login correcto");

			if(data[0].userRole == "ROLE_ESPECIALISTA")
				window.location.href = "/especialista/EspecialistaPage.html";
			else if(data[0].userRole == "ROLE_USER")
				window.location.href = "/usuario/User.html";
			else
				alert("Rol no reconocido");

		}).fail(function(jqXHR, textStatus, errorThrown) {
			alert("Se ha producido un error.");
		});	
	}
	/*
	  // email form submission handler
	  function emailLogin() {
	    var emailAddress = document.getElementById("email").value;
	    AccountKit.login(
	      'EMAIL',
	      {emailAddress: emailAddress},
	      loginCallback
	    );
	  }*/
