
/*
 * Controlador de la página UserLogin.html
 * 
 * 
 * Diseño: Pablo Carmona Rebollo
 * All rights reserved
 * version 3.0.0
 */


/* Funciones a ejecutar en la carga de la página */
$(document).ready(function() {
	// Inicializamos el plugin de validación
	$('#login_form').validate({
		// Establecemos las reglas de validación para
		// cada uno de los campos del formulario
		rules : {
			user_email : {
				required : true,
				email : true
			},
			user_password : {
				required : true,
				minlength : 5
			},			
		},
		// Establecemos la función que se ejecutará en caso
		// de envío del formulario.
		submitHandler : function(form) {
			sendUserData();
		}
	});

});

var bandera = 0;
/* Evento que lanza el envío del formulario */
function submitForm() {
	$("#login_form").submit();
}


/* A diferencia del resto de funciones de envíar datos de usuario. ésta lo que
   hace es crear una cookie con el usuario autenticado para no hardcodear el
   usuario dentro del código y su obtención sea dinámica por parte del 
   programa,aunque pueda autenticarse cualquier usuario debido a que no 
   disponemos de sistema de autenticación.
 */
function sendUserData() {

	//showMeYourCookies('At loginform submission');
	
	
	// Obtenemos los datos del propietario del formulario
	var user_Id = $('[name="user_email"]').val();
	var user_Passw = $('[name="user_password"]').val();
	
	// Obtenemos la cookie de usuario
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	var data = 'username=' + user_Id + '&password=' + user_Passw; 
	console.log(cookie.userid);

	$.ajax({
		data: data,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		timeout: 1000,
		type: "POST",
		url: "/login",
		async:false,
	}).done(function(data, textStatus, jqXHR) {
		// No se informa de nada: 
		// La autenticación del usuario es autodescriptiva		
		// Almacenamos en la cookie RutinaUser la información del usuario
		var cookie = JSON.stringify({method: '', url: '/', csrf: jqXHR.getResponseHeader('X-CSRF-TOKEN'), userid: user_Id});
		$.cookie('RutinaUsuario', cookie);
		//console.log("DATAAA:" + data);
		// Obtenemos la cookie nueva
		var cookie = JSON.parse($.cookie('RutinaUsuario'));
		getUserRole();

	}).fail(function(jqXHR, textStatus, errorThrown) {
		//alert("FALLO1");
		// Informamos de que ha fallado la autenticación
		alert("La contraseña o el correo son erróneos");
		// Redirigimos si recarga la página para recargar la cookie
		//window.location.href = "login.html";
	});
	
	
}

function getUserRole(){
	
	var cookie = JSON.parse($.cookie('RutinaUsuario'));
	//console.log("COOKIE: " + cookie.userid);
	
	$.ajax({
		url : "/Rutina_app/rol/" + cookie.userid,
		headers: {'X-CSRF-TOKEN': cookie.csrf},
		type : "GET",
		contentType : "application/json",
		async:false,
	}).done(function(data, textStatus, jqXHR) {
		//Redireccionamos
		alert("Login correcto");

		if(data[0].userRole == "ROLE_ESPECIALISTA")
			window.location.href = "/especialista/EspecialistaPage.html";
		else if(data[0].userRole == "ROLE_USER")
			window.location.href = "/usuario/User.html";
		else
			alert("Rol no reconocido");

	}).fail(function(jqXHR, textStatus, errorThrown) {
		alert("Se ha producido un error.");
	});	
}
