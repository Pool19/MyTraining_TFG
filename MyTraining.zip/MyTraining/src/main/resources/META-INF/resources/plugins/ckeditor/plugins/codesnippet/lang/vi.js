/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","vi",{button:"Chèn đoạn mã",codeContents:"Nội dung mã",emptySnippetError:"Một đoạn mã không thể để trống.",language:"Ngôn ngữ",title:"Đoạn mã",pathName:"mã dính"});